const arr = [
  ['222', '333'],
  ['男1', '女2'],
  ['22', '33'],
  ['男', '女'],
  ['男12', '女22']
]

// const fullPermutation = arr => {
//   if (arr.length === 1) {
//     return arr[0]
//   }
//   const firstmatrix = arr[0]
//   const restmatix = arr.slice(1)
//   const restResult = fullPermutation(restmatix)
//   const result = []
//   let piece = []
//   for (const v1 of firstmatrix) {
//     for (const v2 of restResult) {
//       piece = Array.isArray(v2) ? [v1, ...v2] : [v1, v2]
//       result.push(piece)
//       piece = []
//     }
//   }
//   return result
// }

const fullPermutation = arr => {
  if (arr.length === 0) {
    return [[]]
  }
  const firstmatrix = arr[0]
  const restmatix = arr.slice(1)
  const restResult = fullPermutation(restmatix)
  const result = []
  let piece = []
  for (const v1 of firstmatrix) {
    for (const v2 of restResult) {
      piece = Array.isArray(v2) ? [v1, ...v2] : [v1, v2]
      result.push(piece)
      piece = []
    }
  }
  return result
}
fullPermutation([['男12', '女22']])
